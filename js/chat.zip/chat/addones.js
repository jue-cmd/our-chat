class extension {
    constructor() {

    }
}
class extensions_manager {
    constructor() {

    }
}